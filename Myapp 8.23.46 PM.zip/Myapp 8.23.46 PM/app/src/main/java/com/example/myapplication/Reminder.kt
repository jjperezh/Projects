package com.example.myapplication
//JORGE PEREZ - AndroidApp - Oct.17

import java.util.*

class Reminder(
    val title: String,
    var isChecked: Boolean = false
)