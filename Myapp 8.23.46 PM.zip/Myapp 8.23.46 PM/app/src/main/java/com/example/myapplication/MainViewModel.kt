package com.example.myapplication
//JORGE PEREZ - AndroidApp - Oct.17
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {

}