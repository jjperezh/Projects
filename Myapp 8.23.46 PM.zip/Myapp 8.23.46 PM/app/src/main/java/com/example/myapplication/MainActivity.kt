package com.example.myapplication
//JORGE PEREZ - AndroidApp - Oct.17

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var todoAdapter: AppAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        val itemsTodo: RecyclerView = findViewById(R.id.itemsTodo)
        val buttonAdd: Button = findViewById(R.id.buttonAdd)
        val toDo: EditText = findViewById(R.id.toDo)

        todoAdapter = AppAdapter(mutableListOf())
        itemsTodo.adapter = todoAdapter
        itemsTodo.layoutManager = LinearLayoutManager(this)

        buttonAdd.setOnClickListener {
            val todoTitle = toDo.text.toString()
            if(todoTitle.isNotEmpty()) {
                val todo = Reminder(todoTitle)
                todoAdapter.todoList(todo)
                toDo.text.clear()
            }
        }
        delete_button.setOnClickListener {
            todoAdapter.deleteTodoList()
        }
    }
}