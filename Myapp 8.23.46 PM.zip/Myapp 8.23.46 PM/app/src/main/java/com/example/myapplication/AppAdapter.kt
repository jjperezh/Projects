package com.example.myapplication
//JORGE PEREZ - AndroidApp - Oct.17

import android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(private val finish: MutableList<Reminder>):
    RecyclerView.Adapter<AppAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_todo,parent,false
            )
        )
    }

    private fun strikeThrough(todoTitle: TextView, isChecked: Boolean){
        if(isChecked){
            todoTitle.paintFlags = todoTitle.paintFlags or STRIKE_THRU_TEXT_FLAG
        }
        else{
            todoTitle.paintFlags = todoTitle.paintFlags and STRIKE_THRU_TEXT_FLAG.inv()
        }
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val curr = finish[position]
        val todoTitle: TextView = holder.itemView.findViewById(R.id.todoTitle)
        val itemDone: CheckBox = holder.itemView.findViewById(R.id.itemDone)

        holder.itemView.apply {
            todoTitle.text = curr.title
            itemDone.isChecked = curr.isChecked
            strikeThrough(todoTitle, curr.isChecked)
            itemDone.setOnCheckedChangeListener{buttonView, isChecked ->
                strikeThrough(todoTitle, isChecked)
                curr.isChecked = !curr.isChecked
            }
        }
    }

    override fun getItemCount() = finish.size

    fun todoList(todo: Reminder){
        finish.add(todo)
        notifyItemInserted(finish.size-1)
    }

    fun deleteTodoList(){
        finish.removeAll{todo -> todo.isChecked}
        notifyDataSetChanged()
    }
}